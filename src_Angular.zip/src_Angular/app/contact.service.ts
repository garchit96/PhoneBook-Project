import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ContactBook } from './PhoneBook';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ContactService {
  baseUrl: string = 'http://localhost:8080/MyPhoneBookProject/rest/contacts/';
  constructor( private http: HttpClient) { }

  fetchAllContacts(): Observable<ContactBook[]>
  {
    return this.http.get<ContactBook[]>(this.baseUrl+"getContacts/");
  }

  fetchAContact(contactName: string): Observable<ContactBook>
  {
    return this.http.get<ContactBook>(this.baseUrl+"getContact/"+ contactName);
  }

  addAContact(newCont: ContactBook): Observable<ContactBook>{
   
    return this.http.post<ContactBook>(this.baseUrl+"addContact/", newCont);
  }

  modifyContact(existingcont: ContactBook): Observable<ContactBook>{
   
    return this.http.put<ContactBook>(this.baseUrl+"updateContact/", existingcont);
  }

  deleteContact(contactName: string) : Observable<ContactBook>{
    return this.http.delete<ContactBook>(this.baseUrl+"deleteContact/" + contactName);

  }

}
