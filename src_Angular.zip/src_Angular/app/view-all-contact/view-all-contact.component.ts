import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ContactService } from '../contact.service';
import { ContactBook } from '../PhoneBook';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';




@Component({
  selector: 'app-view-all-contact',
  templateUrl: './view-all-contact.component.html',
  styleUrls: ['./view-all-contact.component.css']
})
export class ViewAllContactComponent  {
  contName: string="";

  conts: ContactBook[];
  tempConts: ContactBook[];
  cont: ContactBook = new ContactBook();
  closeResult: string;
  private subscription: Subscription;
  constructor(private contService: ContactService , private modalService: NgbModal) { }
    
    
    ngOnInit(){
      this.subscription =this.contService.fetchAllContacts().subscribe((data:ContactBook[])=>{
        this.conts = data;
        this.tempConts = data;
      },(err) =>{
        console.log(err);
      
    });
    }
deleteContact(c: string){
  //console.log('Contact name searched '+c);
  this.contService.deleteContact(c).subscribe((data:ContactBook) => {
    if(data==null){
      this.tempConts=this.conts.filter(d => (d.contactName != c) );
      this.conts = this.tempConts;
      console.log('Record deleted '+c);
    }
  }, (err)=>{
    console.log(err);
  });
}

viewAContact() {
  if(this.contName == null)  {
    console.log('its null : '+this.contName);
    this.tempConts = this.conts;
  }
  else {
    console.log('its not zero : '+this.contName);
    this.tempConts = this.conts.filter(d => (d.contactName == this.contName) );
    
    console.log('tempConts length : '+this.tempConts.length);
    console.log('conts length : '+this.conts.length);
    

  }
  
}
updateContact(){
  this.contService.modifyContact(this.cont).subscribe(data =>{
    
  })
}



    
  // open(content) {
  //   this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
  //     this.closeResult = `Closed with: ${result}`;
  //   }, (reason) => {
  //     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  // }
  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return  `with: ${reason}`;
  //   }
  // }

  
}
