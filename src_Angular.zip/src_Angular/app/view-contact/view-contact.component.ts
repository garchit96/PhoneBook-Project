import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { ContactBook } from '../PhoneBook';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {
  // cont: any;
  // detail: string;
  //cont: ContactBook = new ContactBook();
  contObj: ContactBook;

  constructor(private contService: ContactService) {
  }
  
  ngOnInit() { //3

      this.contService.fetchAContact(this.contObj.contactName).
      subscribe((data: ContactBook) => {
          this.contObj = data;
      }, (err) => {
          console.log(err);
      })
      
  }
  

}




 
