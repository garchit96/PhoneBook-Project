import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { ContactBook } from '../PhoneBook';

@Component({
  selector: 'app-modify-contact',
  templateUrl: './modify-contact.component.html',
  styleUrls: ['./modify-contact.component.css']
})
export class ModifyContactComponent implements OnInit {
cont: ContactBook = new ContactBook();
  constructor(private serv: ContactService) { 
    this.cont.contactName='';
    this.cont.contactNumber='';
  }

  ngOnInit(): void {
  }

  updateContact(){
    this.serv.modifyContact(this.cont).subscribe(data =>{
      
    })
  }
}
