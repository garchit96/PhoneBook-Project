export class ContactBook{
    contactName: string;
    contactNumber: string;
}