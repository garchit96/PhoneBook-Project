import { HttpClient} from '@angular/common/http';
import { Component } from '@angular/core';
import { stringify } from 'querystring';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ContactService } from './contact.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My PhoneBook';
  
  
  constructor( private serv:ContactService, private http: HttpClient){
    // this.serv.fetchAllContacts();
    // this.serv.fetchAContact("contactName ");
  }
}

