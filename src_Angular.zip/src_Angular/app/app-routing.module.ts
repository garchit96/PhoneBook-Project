import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ModifyContactComponent } from './modify-contact/modify-contact.component';
import { ViewAllContactComponent } from './view-all-contact/view-all-contact.component';

const routes: Routes = [
  // {path:'**', redirectTo:'/add', pathMatch:'full'},
   {path: 'add', component: AddContactComponent},
   {path: 'update', component: ModifyContactComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
