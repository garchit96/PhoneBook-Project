import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { ContactBook } from '../PhoneBook';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

cont: ContactBook = new ContactBook();
  constructor(private serv: ContactService) { 
  this.cont.contactName  =   ' ';
  this.cont.contactNumber=   ' ';
}

  ngOnInit(): void {}
  
  addContact() {
    
    this.serv.addAContact(this.cont).subscribe(data => {
      alert(JSON.stringify(data));
     
    })
  }
}
