import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewContactComponent } from './view-contact/view-contact.component';
import { ViewAllContactComponent } from './view-all-contact/view-all-contact.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ModifyContactComponent } from './modify-contact/modify-contact.component';
import { DeleteContactComponent } from './delete-contact/delete-contact.component';
import { ContactService } from './contact.service';
import {  HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {MatIcon, MatIconModule} from '@angular/material/icon'
import {NgbModalModule, NgbModule} from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    AppComponent,
    ViewContactComponent,
    ViewAllContactComponent,
    AddContactComponent,
    ModifyContactComponent,
    DeleteContactComponent,
  ],

  
  imports: [
    BrowserModule,
    AppRoutingModule, 
    HttpClientModule,
    FormsModule,
    MatIconModule,
    NgbModule,
    NgbModalModule

    
  ],
  providers: [ContactService],
  bootstrap: [AppComponent]
})
export class AppModule { }
