package com.myservice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ContactDAO {
		 
	private static final Map<String, Contact> conMap = new HashMap<String, Contact>();
		 
	static {
		        initCon();
		    }
	private static void initCon() {
	        Contact con1 = new Contact( "Aamir", "9415746903"  );
	        Contact con2 = new Contact( "Karan" ,"9415746904"  );
	        Contact con3 = new Contact( "Aditya","9415746908" );
	        Contact con4 = new Contact( "Archit","9415746567" );
	        Contact con5 = new Contact( "Vaibhav","9415745420" );
	        Contact con6 = new Contact( "Ayush","9415746798" );
	 
	        conMap.put(con1.getContactName(), con1);
	        conMap.put(con2.getContactName(), con2);
	        conMap.put(con3.getContactName(), con3);
	        conMap.put(con4.getContactName(), con4);
	        conMap.put(con5.getContactName(), con5);
	        conMap.put(con6.getContactName(), con6);
	    }
	 public static Contact getContact(String contactName) {
	        return conMap.get(contactName);
	    }
	 
	 
	    public static Contact addContact(Contact con) {
	        conMap.put(con.getContactName(), con);
	        return con;
	    }
	    public static Contact updateContact(Contact con) {
	        conMap.put(con.getContactName(), con);
	        return con;
	    }
	 
	    public static void deleteContact(String contactName) {
	        conMap.remove(contactName);
	    }
	 
	    public static List<Contact> getAllContacts() {
	        Collection<Contact> c = conMap.values();
	        List<Contact> list = new ArrayList<Contact>();
	        list.addAll(c);
	        return list;
	    }
	    List<Contact> list;
}
