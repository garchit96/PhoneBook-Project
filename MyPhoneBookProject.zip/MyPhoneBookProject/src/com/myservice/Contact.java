package com.myservice;



//@XmlRootElement(name = "contacts")
public class Contact {
//int cid;

	String contactNumber;
	String contactName;
	
	 public Contact() {
		 
	    }
	 
	    public Contact(String contactName, String contactNumber) {
	        this.contactName = contactName;
	        this.contactNumber= contactNumber;
	     
	    }
	    
//	public Contact(int cid, String contactNumber, String contactName) {
//			super();
//			this.cid = cid;
//			this.contactNumber = contactNumber;
//			this.contactName = contactName;
//		}

//	public int getCid() {
//			return cid;
//		}
//
//		public void setCid(int cid) {
//			this.cid = cid;
//		}

	public String getContactNumber() {
		return contactNumber;
	}
	//@XmlElement
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactName() {
		return contactName;
	}
	//@XmlElement
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	
}
